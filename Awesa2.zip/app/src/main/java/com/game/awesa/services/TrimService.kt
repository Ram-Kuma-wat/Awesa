package com.game.awesa.services

import android.app.Service
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.util.Log
import android.widget.Toast
import com.codersworld.awesalibs.beans.matches.ReactionsBean
import com.codersworld.awesalibs.database.DatabaseHelper
import com.codersworld.awesalibs.database.DatabaseManager
import com.codersworld.awesalibs.database.dao.DBVideoUplaodDao
import com.codersworld.awesalibs.database.dao.MatchActionsDAO
import com.codersworld.awesalibs.database.dao.VideoMasterDAO
import com.codersworld.awesalibs.mp4compose.FillMode
import com.codersworld.awesalibs.mp4compose.composer.Mp4Composer
import com.codersworld.awesalibs.mp4compose.filter.GlFilterGroup
import com.codersworld.awesalibs.mp4compose.filter.GlMonochromeFilter
import com.codersworld.awesalibs.mp4compose.filter.GlVignetteFilter
import com.codersworld.awesalibs.utils.CommonMethods
import com.codersworld.awesalibs.utils.Tags
import com.google.gson.Gson
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date

class TrimService :Service() {
    var list: ArrayList<DBVideoUplaodDao> = ArrayList()


    override fun onCreate() {
        super.onCreate()
        CommonMethods.showLog("Upload Service Create")
        DatabaseManager.initializeInstance(DatabaseHelper(applicationContext))
        getSingleAction()
        fetchMatch(5)
        stopSelf()
    }

    fun fetchMatch(type:Int){
        if (type>=0) {
            DatabaseManager.getInstance().executeQuery { database ->
                val dao = VideoMasterDAO(database, applicationContext)
                list = dao.selectAll()
            }
            if (CommonMethods.isValidArrayList(list)) {
                initVideoView(list[0])
                return
            } else {
            }
        }
    }
    fun getDuration( path: String): Long {
        var mMediaPlayer: MediaPlayer? = null
        var duration: Long = 0
        try {
            mMediaPlayer = MediaPlayer()
            mMediaPlayer.setDataSource(applicationContext, Uri.parse(path))
            mMediaPlayer.prepare()
            duration = mMediaPlayer.duration.toLong()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            if (mMediaPlayer != null) {
                mMediaPlayer.reset()
                mMediaPlayer.release()
                mMediaPlayer = null
            }
        }
        return duration
    }
    fun trim( mDao:DBVideoUplaodDao,mBeanReaction: ReactionsBean) {
        videoLength = getDuration(mDao.video_path)
        var video_path = mDao.video_path
        var start: Long = 0
        var end: Long = 0
        val time = mBeanReaction.time.split(":".toRegex()).dropLastWhile { it.isEmpty() }
            .toTypedArray()
        if (time.size > 0) {
            start =( time[0].toLong() * 60 * 1000 )+ (time[1].toLong()*1000)
        }
        if((start+5000)>videoLength){
            end = videoLength
        }else{
            end= start+5000
        }
        if((start-5000)<0){
            start = 0
        }else{
            start= start-5000
        }
        var mediaFile : File? =null;
        var timeStamp1 = SimpleDateFormat("dd MMM yyyy").format(Date())
        var mediaStorageDir: File? = null
        if (Build.VERSION.SDK_INT >= 30) {
            mediaStorageDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Awesa/trim/"+timeStamp1)
            if (!mediaStorageDir.exists()) {
                if (!mediaStorageDir.mkdirs()) {
                    //return null
                }
            }
        }else{
            mediaStorageDir =getExternalFilesDir("Awesa/trim/"+timeStamp1)
            mediaStorageDir!!.mkdirs()
            if (!mediaStorageDir!!.exists()) {
                if (!mediaStorageDir!!.mkdirs()) {
                }
            }
        }
        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                Toast.makeText(applicationContext, "Please Allow Storage Permission.",Toast.LENGTH_LONG).show()
            }
        }
        val date = Date()
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss")
            .format(date.time)
        // For unique video file name appending current timeStamp with file name
        mediaFile =
            File(mediaStorageDir.path + File.separator + "m_" + mDao.match_id + "_a_"+mBeanReaction.id.toString()+"_h_" + mDao.video_half + ".mp4")
        var fileName = mediaFile.toString()
            .substring(mediaFile.toString().lastIndexOf('/') + 1, mediaFile.toString().length)
        Mp4Composer(video_path, mediaFile.absolutePath)
            .fillMode(FillMode.PRESERVE_ASPECT_FIT)
            .trim(start, end)
            .listener(object : Mp4Composer.Listener {
                override fun onProgress(progress: Double) {
                    Log.e("mresult", "onProgress = $progress")
                }

                override fun onCurrentWrittenVideoTime(timeUs: Long) {
                    Log.e("mresult", "onProgress1 = $timeUs")

                }

                override fun onCompleted() {

                    Log.e("mresult", "onCompleted()")

                    //mBeanReaction
                    DatabaseManager.getInstance().executeQuery { database ->
                        val actionDao = MatchActionsDAO(database, applicationContext)
                        actionDao.updateVideo(fileName,mediaFile.toString(),mBeanReaction.id);
                        getSingleAction()
                    }
                    /*
                                        //runOnUiThread {
                                            counter++;
                                            if(counter < mListReaction.size) {
                                                makeTrim(mDao, counter)
                                            }else{
                                                fetchMatch(2)
                                            }
                                            //trim(video_path,5,5*1000)
                                        //}
                    */
                }

                override fun onCanceled() {
                    getSingleAction()
/*
                    if(counter < mListReaction.size) {
                        makeTrim(mDao, counter)
                    }else{
                        fetchMatch(3)
                    }
*/

                    Log.e("mresult", "onCanceled")
                }

                override  fun onFailed(exception: Exception?) {
                    getSingleAction()
/*
                     if(counter < mListReaction.size) {
                        makeTrim(mDao, counter)
                    }else{
                        fetchMatch(4)
                    }
*/
                    Log.e("mresult", "onFailed()", exception)
                }
            })
            .start()
    }
    var mListReaction:ArrayList<ReactionsBean> =  ArrayList<ReactionsBean>()
    var videoLength : Long=0;
    //66716
    fun makeTrim(mDao:DBVideoUplaodDao,counter1:Int){
        if (mListReaction.size>counter1) {
           // trim(mDao, counter1)
        }
    }
    var counter = 0;
    fun initVideoView(mDao:DBVideoUplaodDao) {
        videoLength = 0;
        var video_path=mDao.video_path
        videoLength = getDuration(video_path)
        mListReaction = java.util.ArrayList()
        DatabaseManager.getInstance().executeQuery { database ->
            val dao = MatchActionsDAO(database, applicationContext)
            // mListReaction = dao.selectAll(mDao.getMatch_id() + "",  "2")
            //   Log.e("mListReaction",Gson().toJson(mListReaction))
            mListReaction = dao.selectAll(mDao.getMatch_id() + "", mDao.getVideo_half() + "",1)
        }
        if(CommonMethods.isValidArrayList(mListReaction)) {
            makeTrim(mDao, counter)
        }else{
            DatabaseManager.getInstance().executeQuery { database ->
                val dao = VideoMasterDAO(database, applicationContext)
                dao.deleteVideoById(mDao.getmId());
                try{
                    var file: File = File(mDao.video_path)
                    file.delete()
                    if (file.exists()) {
                        file.canonicalFile.delete()
                        if (file.exists()) {
                            applicationContext.deleteFile(file.name)
                        }
                    }
                }catch (ex:Exception){
                    ex.printStackTrace()
                }
                fetchMatch(5)
            }
        }
    }



    override fun onDestroy() {
        super.onDestroy()
        CommonMethods.showLog("Upload Service Destroy")
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        CommonMethods.showLog("Upload Service onStartCommand")
        return super.onStartCommand(intent, flags, startId)
    }

    fun getSingleAction(){
        mListReaction = ArrayList()
        DatabaseManager.getInstance().executeQuery { database ->
            val dao = MatchActionsDAO(database, applicationContext)
            // mListReaction = dao.selectAll(mDao.getMatch_id() + "",  "2")
            mListReaction = dao.selectSingle(0)
            if(CommonMethods.isValidArrayList(mListReaction)){
                val dao1 = VideoMasterDAO(database, applicationContext)
                //list = dao1.selectAll1("","")
                list = dao1.selectAll1(mListReaction[0].match_id.toString(),mListReaction[0].half.toString())
                if (CommonMethods.isValidArrayList(list)) {
                    trim(list[0], mListReaction[0])
                }
            }else{
                Log.e("errrr","errrrrrr")
            }
        }
    }

}