package com.game.awesa.ui.matches

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.codersworld.awesalibs.beans.CommonBean
import com.codersworld.awesalibs.beans.leagues.LeagueBean
import com.codersworld.awesalibs.beans.matches.MatchesBean
import com.codersworld.awesalibs.database.DatabaseHelper
import com.codersworld.awesalibs.database.DatabaseManager
import com.codersworld.awesalibs.listeners.OnConfirmListener
import com.codersworld.awesalibs.listeners.OnLeagueListener
import com.codersworld.awesalibs.listeners.OnMatchListener
import com.codersworld.awesalibs.listeners.OnResponse
import com.codersworld.awesalibs.rest.ApiCall
import com.codersworld.awesalibs.rest.UniverSelObjct
import com.codersworld.awesalibs.storage.UserSessions
import com.codersworld.awesalibs.utils.CommonMethods
import com.codersworld.awesalibs.utils.Logs
import com.codersworld.awesalibs.utils.Tags
import com.game.awesa.R
import com.game.awesa.databinding.ActivityLeagueBinding
import com.game.awesa.databinding.ActivityMatchDetailBinding
import com.game.awesa.ui.BaseActivity
import com.game.awesa.ui.dashboard.MainActivity
import com.game.awesa.ui.league.adapter.LeagueAdapter
import com.game.awesa.ui.recorder.VideoPreviewActivity
import com.game.awesa.ui.teams.OpponentTeamsActivity


class MatchDetailActivity : BaseActivity(), OnConfirmListener,OnResponse<UniverSelObjct>,
    OnMatchListener {
    lateinit var binding: ActivityMatchDetailBinding
    var mApiCall: ApiCall? = null
    var game_id=""
     lateinit var matchBean : MatchesBean.InfoBean

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_match_detail)
        initApiCall()
        DatabaseManager.initializeInstance(DatabaseHelper(this@MatchDetailActivity))
        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.imgHome.setOnClickListener { CommonMethods.moveWithClear(this@MatchDetailActivity,MainActivity::class.java) }
        binding.rvHistory.layoutManager = LinearLayoutManager(this@MatchDetailActivity,RecyclerView.VERTICAL,false)
         if (intent.hasExtra("game_id")) {
            game_id = intent.getStringExtra("game_id") as String
        }
        if (intent.hasExtra("matchBean")) {
            matchBean = CommonMethods.getSerializable(intent,"matchBean", MatchesBean.InfoBean::class.java)
         }
        getMatches()
        binding.swRefresh.setOnRefreshListener {
            getMatches()
        }
     }

    fun initApiCall() {
        if (mApiCall == null) {
            mApiCall = ApiCall(this@MatchDetailActivity)
        }
    }
    override fun onConfirm(isTrue: Boolean, type: String) {
    }

    override fun onSuccess(response: UniverSelObjct) {
        binding.swRefresh.isRefreshing=false
        try {
            Logs.e(response.methodname.toString())
            when (response.methodname) {
                Tags.SB_MATCH_DETAIL_API -> {
                    var mBeanMatch: MatchesBean = response.response as MatchesBean
                    if (mBeanMatch.status == 1 && CommonMethods.isValidArrayList(mBeanMatch.info)) {
                        CommonMethods.loadImage(this@MatchDetailActivity,mBeanMatch.info[0].team1_image,binding.imgTeam1)
                        CommonMethods.loadImage(this@MatchDetailActivity,mBeanMatch.info[0].team2_image,binding.imgTeam2)
                        if (CommonMethods.isValidString(mBeanMatch.info[0].interview)){
                            binding.llInterview.visibility=View.VISIBLE
                            CommonMethods.loadImage(this@MatchDetailActivity,mBeanMatch.info[0].interview_thumbnail,binding.imgThumbnail)
                            binding.rlPlay.setOnClickListener {
                                var mBeanVideo :MatchesBean.VideosBean = MatchesBean.VideosBean()
                                mBeanVideo.video = mBeanMatch.info[0].interview
                                startActivity(Intent(this@MatchDetailActivity,VideoPreviewActivity::class.java).putExtra("mBeanVideo",mBeanVideo))
                            }
                        }else{
                            binding.llInterview.visibility=View.GONE
                        }
                        if (CommonMethods.isValidArrayList((mBeanMatch.info[0].videos)) || CommonMethods.isValidString(mBeanMatch.info[0].interview)){
                            binding.rvHistory.adapter = VideosAdapter(this@MatchDetailActivity,mBeanMatch.info[0].videos,this@MatchDetailActivity);
                            CommonMethods.changeView(binding.mNestedScroll,binding.llNoData)
                        }else{
                            CommonMethods.changeView(binding.llNoData,binding.mNestedScroll)
                        }
                    }else if (CommonMethods.isValidString(mBeanMatch.msg)) {
                        errorMsg(mBeanMatch.msg);
                    } else {
                        errorMsg(getResources().getString(R.string.something_wrong));
                    }
                }
            }
        } catch (ex: Exception) {
            ex.printStackTrace()
            errorMsg(getResources().getString(R.string.something_wrong));
        }
        //method body
    }

    fun errorMsg(strMsg: String) {
        CommonMethods.changeView(binding.llNoData,binding.mNestedScroll)
        CommonMethods.errorDialog(this@MatchDetailActivity,strMsg,getResources().getString(R.string.app_name),getResources().getString(R.string.lbl_ok));
    }

    override fun onError(type: String, error: String) {
        errorMsg(error)
        //method body
    }

    fun getMatches() {
        if (CommonMethods.isNetworkAvailable(this@MatchDetailActivity)) {
            mApiCall!!.getMatchDetail(this, true, UserSessions.getUserInfo(this@MatchDetailActivity).id.toString(), game_id)
        } else {
            CommonMethods.errorDialog(
                this@MatchDetailActivity,
                getResources().getString(R.string.error_internet),
                getResources().getString(R.string.app_name),
                getResources().getString(R.string.lbl_ok)
            );
        }
    }

    override fun onMatchClick(mBeanMatch: MatchesBean.InfoBean?) {
        //
    }

    override fun onVideoClick(mBeanVideo: MatchesBean.VideosBean?) {
        if (mBeanVideo !=null && CommonMethods.isValidString(mBeanVideo!!.video)) {
            startActivity(
                Intent(
                    this@MatchDetailActivity,
                    VideoPreviewActivity::class.java
                ).putExtra("mBeanVideo", mBeanVideo)
            )
        }
    }
}