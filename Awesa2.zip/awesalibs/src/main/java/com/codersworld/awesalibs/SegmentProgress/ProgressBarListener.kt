package com.codersworld.awesalibs.SegmentProgress

interface ProgressBarListener {
    fun TimeinMill(mills: Long)
}