package com.codersworld.awesalibs.autoimageslider.SegmentProgress;

/**
 * Created by AQEEL on 3/26/2019.
 */

public interface  ProgressBarListener {

    void TimeinMill(long mills);
}
