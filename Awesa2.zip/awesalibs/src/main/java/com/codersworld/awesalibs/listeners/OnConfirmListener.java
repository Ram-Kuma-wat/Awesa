package com.codersworld.awesalibs.listeners;

public interface OnConfirmListener {
    void onConfirm(Boolean isTrue,String type);
}
