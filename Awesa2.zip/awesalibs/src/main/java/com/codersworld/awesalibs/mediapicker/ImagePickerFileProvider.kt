package com.codersworld.awesalibs.mediapicker

import androidx.core.content.FileProvider

class ImagePickerFileProvider : FileProvider()
