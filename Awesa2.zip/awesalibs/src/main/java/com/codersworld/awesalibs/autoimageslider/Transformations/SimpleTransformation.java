package com.codersworld.awesalibs.autoimageslider.Transformations;

import com.codersworld.awesalibs.autoimageslider.SliderPager;
import android.view.View;

public class SimpleTransformation implements SliderPager.PageTransformer {
    @Override
    public void transformPage(View page, float position) {

    }
}