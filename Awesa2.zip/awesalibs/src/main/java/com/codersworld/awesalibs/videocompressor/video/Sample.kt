package com.codersworld.awesalibs.videocompressor.video

data class Sample(var offset: Long, var size: Long)
