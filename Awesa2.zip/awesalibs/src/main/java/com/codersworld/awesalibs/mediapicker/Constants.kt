package com.codersworld.awesalibs.mediapicker;

internal const val dateFormatForTakePicture = "yyyyMMdd_HHmmss"
internal const val EXTRA_IMAGE_PICKER_CONFIG = "extra-picker-config"
internal const val MB_TO_BYTE_MULTIPLIER = 1e+6
internal const val MAX_PICK_LIMIT = 15