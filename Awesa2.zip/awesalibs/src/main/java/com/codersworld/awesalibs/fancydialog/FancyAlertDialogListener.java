package com.codersworld.awesalibs.fancydialog;

import android.app.Dialog;

public interface FancyAlertDialogListener {
    void onClick(Dialog dialog);
}
