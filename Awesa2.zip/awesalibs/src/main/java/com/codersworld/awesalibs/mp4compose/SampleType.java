package com.codersworld.awesalibs.mp4compose;

public enum SampleType {VIDEO, AUDIO}
