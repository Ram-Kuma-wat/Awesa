package com.codersworld.awesalibs.listeners;

public interface OnPageChangeListener {
    void onPageChange(String mPage);
}
