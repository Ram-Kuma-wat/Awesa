package com.codersworld.awesalibs.listeners;

import com.codersworld.awesalibs.beans.leagues.LeagueBean;

public interface OnLeagueListener {
    void onLeagueSelection(LeagueBean.InfoBean mBeanLeague);
}
