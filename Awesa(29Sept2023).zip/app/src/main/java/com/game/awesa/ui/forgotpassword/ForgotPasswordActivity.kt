package com.game.awesa.ui.forgotpassword

import android.annotation.SuppressLint
import android.content.Intent
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.View
import android.view.View.OnClickListener
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.multidex.BuildConfig
import com.codersworld.awesalibs.beans.CommonBean
import com.codersworld.awesalibs.database.DatabaseHelper
import com.codersworld.awesalibs.database.DatabaseManager
import com.codersworld.awesalibs.listeners.OnConfirmListener
import com.codersworld.awesalibs.listeners.OnResponse
import com.codersworld.awesalibs.rest.ApiCall
import com.codersworld.awesalibs.rest.UniverSelObjct
import com.codersworld.awesalibs.storage.UserSessions
import com.codersworld.awesalibs.utils.CommonMethods
import com.codersworld.awesalibs.utils.Logs
import com.codersworld.awesalibs.utils.Tags
import com.game.awesa.R
import com.game.awesa.databinding.ActivityForgotPasswordBinding
import com.game.awesa.ui.VerifyActivity
import com.google.android.exoplayer2.upstream.cache.CacheDataSink
import com.google.gson.Gson
import java.io.File
import java.io.IOException
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date

class ForgotPasswordActivity : AppCompatActivity(), OnConfirmListener, OnClickListener,
    OnResponse<UniverSelObjct> {
    lateinit var binding: ActivityForgotPasswordBinding
    var mApiCall: ApiCall? = null
    var strEmail: String = "";
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_forgot_password)
        UserSessions.saveIsProfile(this@ForgotPasswordActivity, "-1")
        initApiCall()
        if (intent.hasExtra("strEmail")) {
            strEmail = intent.getStringExtra("strEmail") as String
            if (CommonMethods.isValidString(strEmail)) {
                binding.etEmail.setText(strEmail)
            }
        }

        // database handler
        DatabaseManager.initializeInstance(DatabaseHelper(this@ForgotPasswordActivity))
        trim("00:10")
        binding.btnSubmit.setOnClickListener(this)
        binding.toolbar.setNavigationOnClickListener { finish() }

    }

    fun initApiCall() {
        if (mApiCall == null) {
            mApiCall = ApiCall(this@ForgotPasswordActivity)
        }
    }

    override fun onConfirm(isTrue: Boolean, type: String) {
        //method body
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.btnSubmit -> {
                validateLogin()
            }
        }
    }

    override fun onSuccess(response: UniverSelObjct) {
        try {
            Logs.e(response.methodname.toString())
            when (response.methodname) {
                Tags.SB_FORGOT_PASSWORD_API -> {
                    var mCommonBean: CommonBean = response.response as CommonBean
                    if (mCommonBean.status == 1) {
                        startActivity(
                            Intent(
                                this@ForgotPasswordActivity,
                                VerifyActivity::class.java
                            ).putExtra("mCommonBean", mCommonBean)
                                .putExtra("strEmail", binding.etEmail.text.toString())
                                .putExtra("from", "2")
                        )
                    } else if (CommonMethods.isValidString(mCommonBean.msg)) {
                        errorMsg(mCommonBean.msg);
                    } else {
                        errorMsg(getResources().getString(R.string.something_wrong));
                    }
                }
            }
        } catch (ex: Exception) {
            ex.printStackTrace()
            errorMsg(getResources().getString(R.string.something_wrong));
        }
        //method body
    }

    fun errorMsg(strMsg: String) {
        CommonMethods.errorDialog(
            this@ForgotPasswordActivity,
            strMsg,
            getResources().getString(R.string.app_name),
            getResources().getString(R.string.lbl_ok)
        );
    }

    override fun onError(type: String, error: String) {
        errorMsg(error)
        //method body
    }

    fun validateLogin() {
        var strUsername =/* "kumawat";*/binding.etEmail.text.toString()
        if (!CommonMethods.isValidString(strUsername)) {
            CommonMethods.setError(
                binding.etEmail,
                this@ForgotPasswordActivity,
                getString(R.string.email_required),
                getString(R.string.email_required)
            )
        } else if (CommonMethods.checkEmail(strUsername, this@ForgotPasswordActivity) != -1) {
            CommonMethods.setError(
                binding.etEmail,
                this@ForgotPasswordActivity,
                getString(R.string.error_email_invalid),
                getString(R.string.error_email_invalid)
            )
        } else {
            makeAction(strUsername)
        }
    }

    fun makeAction(vararg strParams: String) {
        if (CommonMethods.isNetworkAvailable(this@ForgotPasswordActivity)) {
            mApiCall!!.forgotPassword(
                this,
                strParams[0],
                UserSessions.getFcmToken(this@ForgotPasswordActivity)
            )
        } else {
            CommonMethods.errorDialog(
                this@ForgotPasswordActivity,
                getResources().getString(R.string.error_internet),
                getResources().getString(R.string.app_name),
                getResources().getString(R.string.lbl_ok),
            );
        }
    }

    fun trim(time: String) {
        var mediaFile: File? = null;
        var timeStamp1 = SimpleDateFormat("dd MMM yyyy").format(Date())
        var mediaStorageDir: File? = null
        if (Build.VERSION.SDK_INT >= 30) {
            mediaStorageDir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                "Awesa/trim/" + timeStamp1
            )
            if (!mediaStorageDir.exists()) {
                if (!mediaStorageDir.mkdirs()) {
                    //return null
                }
            }
        } else {
            mediaStorageDir = getExternalFilesDir("Awesa/trim/" + timeStamp1)
            mediaStorageDir!!.mkdirs()
            if (!mediaStorageDir!!.exists()) {
                if (!mediaStorageDir!!.mkdirs()) {
                }
            }
        }
        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                Toast.makeText(
                    applicationContext,
                    "Please Allow Storage Permission.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
        val date = Date()
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss")
            .format(date.time)
        // For unique video file name appending current timeStamp with file name
        mediaFile =
            File(mediaStorageDir.path + File.separator + "m_" + timeStamp + "_trim.mp4")
        var fileName = mediaFile.toString()
            .substring(mediaFile.toString().lastIndexOf('/') + 1, mediaFile.toString().length)
        var srcPath =
            "/storage/emulated/0/Pictures/Awesa/videos/20 Sep 2023/video.mp4";
        var videoLength = getDuration(srcPath)

        var start: Long = 0
        var end: Long = 0
        val time = time.split(":".toRegex()).dropLastWhile { it.isEmpty() }
            .toTypedArray()
        if (time.size > 0) {
            start = (time[0].toLong() * 60 * 1000) + (time[1].toLong() * 1000)
        }
        if ((start + 5000) > videoLength) {
            end = videoLength
        } else {
            end = start + 5000
        }
        if ((start - 5000) < 0) {
            start = 0
        } else {
            start = start - 5000
        }



        genVideoUsingMuxer(mediaFile.absolutePath, start, end)
    }

    fun getDuration(path: String): Long {
        var mMediaPlayer: MediaPlayer? = null
        var duration: Long = 0
        try {
            mMediaPlayer = MediaPlayer()
            mMediaPlayer.setDataSource(applicationContext, Uri.parse(path))
            mMediaPlayer.prepare()
            duration = mMediaPlayer.duration.toLong()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            if (mMediaPlayer != null) {
                mMediaPlayer.reset()
                mMediaPlayer.release()
                mMediaPlayer = null
            }
        }
        return duration
    }

    @SuppressLint("WrongConstant")
    @Throws(IOException::class)
    private fun genVideoUsingMuxer(
        dstPath: String,
        startMs: Long,
        endMs: Long
    ) {
        var srcPath =
            "/storage/emulated/0/Pictures/Awesa/videos/20 Sep 2023/video.mp4";
        var useAudio = true;
        var useVideo = true;
        // Set up MediaExtractor to read from the source.
        val extractor = MediaExtractor()
        extractor.setDataSource(srcPath)
        val trackCount = extractor.trackCount
        // Set up MediaMuxer for the destination.
        val muxer: MediaMuxer
        muxer = MediaMuxer(dstPath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        // Set up the tracks and retrieve the max buffer size for selected
        // tracks.
        val indexMap = HashMap<Int, Int>(trackCount)
        var bufferSize = -1
        for (i in 0 until trackCount) {
            val format = extractor.getTrackFormat(i)
            val mime = format.getString(MediaFormat.KEY_MIME)
            var selectCurrentTrack = false
            if (mime!!.startsWith("audio/") && useAudio) {
                selectCurrentTrack = true
            } else if (mime.startsWith("video/") && useVideo) {
                selectCurrentTrack = true
            }
            if (selectCurrentTrack) {
                extractor.selectTrack(i)
                val dstIndex = muxer.addTrack(format)
                indexMap[i] = dstIndex
                if (format.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                    val newSize = format.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE)
                    bufferSize = if (newSize > bufferSize) newSize else bufferSize
                }
            }
        }
        if (bufferSize < 0) {
            bufferSize = CacheDataSink.DEFAULT_BUFFER_SIZE
        }
        // Set up the orientation and starting time for extractor.
        val retrieverSrc = MediaMetadataRetriever()
        retrieverSrc.setDataSource(srcPath)
        val degreesString = retrieverSrc.extractMetadata(
            MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION
        )
        if (degreesString != null) {
            val degrees = degreesString.toInt()
            if (degrees >= 0) {
                muxer.setOrientationHint(degrees)
            }
        }
        if (startMs > 0) {
            extractor.seekTo((startMs * 1000).toLong(), MediaExtractor.SEEK_TO_CLOSEST_SYNC)
        }
        // Copy the samples from MediaExtractor to MediaMuxer. We will loop
        // for copying each sample and stop when we get to the end of the source
        // file or exceed the end time of the trimming.
        val offset = 0
        var trackIndex = -1
        val dstBuf = ByteBuffer.allocate(bufferSize)
        val bufferInfo = MediaCodec.BufferInfo()
        try {
            muxer.start()
            while (true) {
                bufferInfo.offset = offset
                bufferInfo.size = extractor.readSampleData(dstBuf, offset)
                if (bufferInfo.size < 0) {
                    Log.d("TRIM", "Saw input EOS.")
                    bufferInfo.size = 0
                    break
                } else {
                    bufferInfo.presentationTimeUs = extractor.sampleTime
                    if (endMs > 0 && bufferInfo.presentationTimeUs > (endMs * 1000)) {
                        Log.d("TRIM", "The current sample is over the trim end time.")
                        // trim("00:10")

                        break
                    } else {
                        bufferInfo.flags = extractor.sampleFlags
                        trackIndex = extractor.sampleTrackIndex
                        muxer.writeSampleData(
                            indexMap[trackIndex]!!, dstBuf,
                            bufferInfo
                        )
                        extractor.advance()
                    }
                }
            }
            muxer.stop()
            if (counter == 0) {
                counter++;
                trim("00:15")
            }
            //deleting the old file
            val file = File(srcPath)
            file.delete()
        } catch (e: IllegalStateException) {
            // Swallow the exception due to malformed source.
            Log.w("TRIM", "The source video file is malformed")
        } finally {
            muxer.release()
        }
        return
    }

    var counter = 0;
}