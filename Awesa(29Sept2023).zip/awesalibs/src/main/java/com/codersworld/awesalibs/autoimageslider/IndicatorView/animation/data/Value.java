package com.codersworld.awesalibs.autoimageslider.IndicatorView.animation.data;

public interface Value {/*empty*/}
