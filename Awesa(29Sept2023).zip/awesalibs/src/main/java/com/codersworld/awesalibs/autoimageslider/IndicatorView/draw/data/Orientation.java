package com.codersworld.awesalibs.autoimageslider.IndicatorView.draw.data;

public enum Orientation {HORIZONTAL, VERTICAL}
