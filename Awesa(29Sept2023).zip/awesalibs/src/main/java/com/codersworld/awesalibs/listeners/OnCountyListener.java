package com.codersworld.awesalibs.listeners;

import com.codersworld.awesalibs.beans.county.CountyBean;
import com.codersworld.awesalibs.beans.teams.TeamsBean;

public interface OnCountyListener {
    void onCountySelection(CountyBean.InfoBean mBeanTeam);
}
