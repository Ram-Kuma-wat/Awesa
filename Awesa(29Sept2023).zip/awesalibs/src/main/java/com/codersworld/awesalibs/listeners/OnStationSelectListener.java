package com.codersworld.awesalibs.listeners;

public interface OnStationSelectListener {
    void onStationSelect(String strStation);
 }
