package com.codersworld.awesalibs.autoimageslider.IndicatorView.draw.data;

public enum RtlMode {On, Off, Auto}