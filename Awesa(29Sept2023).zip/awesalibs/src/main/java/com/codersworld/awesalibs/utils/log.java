package com.codersworld.awesalibs.utils;

import android.util.Log;

public class log {
    public static final String TAG = "Awesa";
    public final static void e(String text) {
        Log.e(TAG, text);
    }
}
