package com.codersworld.awesalibs.listeners;

import com.codersworld.awesalibs.beans.teams.TeamsBean;

public interface OnTeamsListener {
    void onTeamSelection(TeamsBean.InfoBean mBeanTeam);
}
