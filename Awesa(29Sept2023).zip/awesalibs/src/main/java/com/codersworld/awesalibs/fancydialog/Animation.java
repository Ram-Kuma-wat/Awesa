package com.codersworld.awesalibs.fancydialog;


public enum Animation {
    POP, SIDE, SLIDE
}
